package chm.writer.hibernate.Entity;

/**
 * 索引HTML文件,用于构建HHK文件
 * @author smilethat@qq.com
 */
public class IndexHtmlFile {
	private int id;
	private String path;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getPath() {
		return path;
	}
	public void setPath(String path) {
		this.path = path;
	}
	
}
