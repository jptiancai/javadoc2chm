package chm.writer.hibernate.Entity;

/**
 * 文件路径,用于构建HHP文件
 * @author smilethat@qq.com
 */
public class FilePath {
	private int id;
	private String path;
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}
	
	public String toString(){
		return String.format("id:%d;path:%s", id,path);
	}
}
