package chm.writer;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 
 * 主类
 * 2012-3-8
 * @author smilethat@qq.com
 * 
 */
public class CHM {
	/**
	 * 
	 * 键值对
	 * @author smilethat@qq.com
	 * 
	 */
	class Pair {
		private String key;
		private String value;

		public Pair(String key, String value) {
			this.key = key;
			this.value = value;
		}

		public String getKey() {
			return key;
		}

		public void setKey(String key) {
			this.key = key;
		}

		public String getValue() {
			return value;
		}

		public void setValue(String value) {
			this.value = value;
		}
	}
	/**
	 * 将字符串保存为文本文件
	 * 
	 * @param txt
	 *            字符串
	 * @param path
	 *            文本文件路径,例如"C:\test.txt"
	 * @return 保存是否成功
	 */
	private boolean saveFile(String txt, String path) {
		boolean result = false;
		FileOutputStream out = null;// 文件输出流
		try {
			out = new FileOutputStream(path);
			out.write(txt.getBytes("gb2312"));
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (out != null) {
					out.close();
				}
			} catch (Exception e) {
			}
		}
		return result;
	}
	/**
	 * 获取html文件的页面标题
	 * 
	 * @param path
	 *            html文件路径,例如"c:\test.html"
	 * @return 页面标题
	 */
	public String getTitle(String path) {
		String title = "";
		FileInputStream in = null;// 文件输入流
		try {
			in = new FileInputStream(path);
			byte[] bytes = new byte[in.available()];
			in.read(bytes);// 文件->byte[]
			//判断文本文件字符类型
			String charsetName="gb2312";//ANSI
			if(bytes.length>=3){
				if(bytes[0]==(byte)0xEF && bytes[1]==(byte)0xBB && bytes[2]==(byte)0xBF){
					charsetName="utf-8";
				}
			}
			String txt = new String(bytes,charsetName);// byte[]->String
			// 利用正则表达式查找页面标题(位于<title>标签内)
			Pattern pattern = Pattern.compile("(<title>)([^<(]*)",
					Pattern.CASE_INSENSITIVE);// 不区分大小写
			Matcher matcher = pattern.matcher(txt);// 进行匹配
			if (matcher.find()) {// 找到
				title = matcher.group(2).trim();// group(1)的值为"<title>",group(2)的值为标题,标题要去掉左右空白字符(包括回车换行符)
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (in != null) {
					in.close();
				}
			} catch (Exception e) {
			}
		}
		return title;
	}

	/**
	 * 获取文件后缀
	 * 
	 * @param path
	 *            文件路径,流入"c:\test.html"
	 * @return 文件后缀,例如".html"
	 */
	private String getFileExt(String path) {
		int beginIndex = path.lastIndexOf(".");
		if (beginIndex == -1) {//找不到"."
			return "";
		} else {
			return path.substring(beginIndex).toLowerCase();// 转换成小写
		}
	}

	/**
	 * 递归函数,用于遍历文件夹,获取相应信息
	 * 
	 * @param lst
	 *            用于生成hhk文件和hhp的[FILES]节
	 * @param sb
	 *            用于存储hhc文件的内容
	 * @param file
	 *            当前考察路径
	 * @param root
	 *            当前考察路径是否是根目录
	 * @param beginIndex
	 *            字符串索引开始处,用于截取绝对路径,变成相对路径
	 */
	private void parse(List<Pair> lst, StringBuilder sb, File file, boolean root,int beginIndex) {
		if (file.isDirectory()) {// 文件夹
			if (root) {// 根目录
				sb.append("<!DOCTYPE HTML PUBLIC \"-//IETF//DTD HTML//EN\">");
				sb.append("<HTML><HEAD></HEAD><BODY>");
				sb.append("<OBJECT type=\"text/site properties\"><param name=\"Window Styles\" value=\"0x800025\"></OBJECT>");
			} else {// 非根目录
				String name = file.getName();// 文件名
				sb.append(String
						.format("\n<LI><OBJECT type=\"text/sitemap\"><param name=\"Name\" value=\"%s\"></OBJECT>",
								name));
			}
			sb.append("<UL>");
			for (File subFile : file.listFiles()) {// 遍历文件夹下所有"文件/文件夹"
				parse(lst, sb, subFile, false,beginIndex);
			}
			sb.append("</UL>");
			if (root) {
				sb.append("</BODY></HTML>");
			}
		} else {// 文件
			String path = file.getAbsolutePath();// 文件绝对路径
			String ext = getFileExt(path);//后缀
			if (ext.equals(".htm") || ext.equals(".html")) {// html文件
				if (!file.getName().equals("allclasses-frame.html")) {// 过滤掉allclasses-frame.html,因为与allclasses-noframe.html内容重复
					String name = getTitle(path);// 页面标题
					if (!name.isEmpty()) {// 标题非空
						path=path.substring(beginIndex);//转为相对路径
						lst.add(new Pair(name, path));
						sb.append(String
								.format("\n<LI><OBJECT type=\"text/sitemap\"><param name=\"Name\" value=\"%s\"><param name=\"Local\" value=\"%s\"></OBJECT>",
										name, path));
					}
				}
			}
		}
	}
	/**
	 * @param lst
	 * @return HHK文件内容
	 */
	private String toHHK(List<Pair> lst) {
		StringBuilder sb = new StringBuilder();
		sb.append("<!DOCTYPE HTML PUBLIC \"-//IETF//DTD HTML//EN\">");
		sb.append("<HTML><HEAD></HEAD><BODY><UL>");
		for (Pair pair : lst) {
			sb.append("\n<LI><OBJECT type=\"text/sitemap\">");
			sb.append(String.format("\n<param name=\"Name\" value=\"%s\">",
					pair.getKey()));// 键
			sb.append(String.format("\n<param name=\"Local\" value=\"%s\">",
					pair.getValue()));// 值
			sb.append("\n</OBJECT>");
		}
		sb.append("</UL></BODY></HTML>");
		return sb.toString();
	}

	/**
	 * @param compiledFile 待生成的chm文件路径,例如"C:\api.chm"
	 * @param files
	 * @return HHP文件内容
	 */
	private String toHHP(String compiledFile, String[] files) {
		StringBuilder sb = new StringBuilder();
		// 写入[OPTIONS]
		sb.append("[OPTIONS]\n");
		sb.append("Compatibility=1.1 or later\n");
		sb.append(String.format("Compiled file=%s\n", compiledFile));
		sb.append(String.format("Title=%s\n", new File(compiledFile).getName()));//chm标题同文件名相同
		sb.append("Contents file=tmp.hhc\n");//目录
		sb.append("Index file=tmp.hhk\n");//索引
		sb.append("Language=0x804 中文(中国)\n");//语言:简体中文
		// 写入[FILES]
		sb.append("[FILES]\n");
		for (String file : files) {
			sb.append(String.format("%s\n", file));
		}
		return sb.toString();
	}

	/**
	 * 删除文件
	 * 
	 * @param path
	 *            待删除的文件路径,例如"tmp.hhp"
	 */
	private void deleteFile(String path) {
		new File(path).delete();
	}

	/**
	 * 生成chm
	 * 
	 * @param path
	 *            JAVA doc文档路径,例如"c:\docs\javadoc"
	 * @param chmName
	 *            待生成的chm文件名,例如"api.chm"
	 */
	public void generate(String path, String chmName) {
		if(path.charAt(path.length()-1)!='\\'){
			path+="\\";
		}
		//hhp,hhc,hhk文件路径
		String hhpPath=path+"tmp.hhp";
		String hhcPath=path+"tmp.hhc";
		String hhkPath=path+"tmp.hhk";
		//获取相应信息
		StringBuilder sb = new StringBuilder();
		List<Pair> lst = new ArrayList<CHM.Pair>();//存储键值对
		parse(lst, sb, new File(path), true,path.length());//遍历path,对lst,sb赋值
		// 生成目录文件(tmp.hhc)
		saveFile(sb.toString(), hhcPath);
		// 生成索引文件(tmp.hhk)
		saveFile(toHHK(lst), hhkPath);
		// 生成工程文件(tmp.hhp)
		String[] files = new String[lst.size()];
		for (int i = 0; i < lst.size(); i++) {
			files[i] = lst.get(i).getValue();
		}
		saveFile(toHHP(new File(chmName).getAbsolutePath(), files), hhpPath);
		InputStream in=null;
		try {
			// 调用hhc.exe
			Process process = Runtime.getRuntime().exec(String.format("hhc\\hhc.exe %s", hhpPath));
			in=process.getInputStream();
			while(true){//等待hhc.exe进程的结束
				if(in.read()==-1){
					break;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				if(in!=null){
					in.close();
				}
			} catch (Exception e) {
			}
		}
		// 删除临时文件
		deleteFile(hhkPath);
		deleteFile(hhcPath);
		deleteFile(hhpPath);
	}

	/**
	 * 主函数
	 * @param args
	 */
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in,"GBK");//用于控制台输入
		scanner.useDelimiter("\r\n");//设置分隔符
		System.out.println("欢迎使用JAVA doc文档转CHM工具V1.2\n"
				+ "程序只能运行在Windows平台上,作者:smilethat@qq.com");
		while (true) {
			System.out.println("请输入JAVA doc文档目录,例如:c:\\docs\\javadoc");
			String path = scanner.next();
			//判断path有效性
			File tmp=new File(path);
			if(!tmp.exists()||!tmp.isDirectory()){
				System.out.println("指定路径不是一个有效的目录");
				continue;
			}
			System.out.println("请输入待生成的chm文件名,例如:api.chm");
			String chmName = scanner.next();
			System.out.println(String.format(
					"您的JAVA doc文档目录是%s,\n待生成的chm文件名是%s\n确定输入y;\n否则输入n,重新进行输入", path,
					chmName));
			String key = scanner.next();
			if (key.toLowerCase().equals("y")) {
				System.out.println("正在生成(如果doc文档较大,将耗费较长时间)...");
				new CHM().generate(path, chmName);//新建CHM对象,生成chm文件
				break;
			} else {
				continue;
			}
		}
		System.out.println("程序运行完毕!");
		scanner.close();
	}
}
