package chm.writer.hh;

import java.io.File;
import java.io.IOException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import chm.writer.Util;
import chm.writer.hibernate.HibernateHelper;
import chm.writer.hibernate.Entity.FilePath;
import chm.writer.hibernate.Entity.IndexHtmlFile;

/**
 * 目录Contents文件
 * @author smilethat@qq.com
 */
public class HHC extends HH {
	private String docPath;
	/**
	 * 假设docPath="D:/jdocs"
	 * beginIndex=docPath.length()+1=9,
	 * 换算绝对路径时，
	 * 例如"D:/jdocs/index.html".substring(beginIndex)="index.html"
	 */
	private int beginIndex;
	/**
	 * @param path hhc文件路径
	 * @param docPath Java Doc目录
	 */
	public HHC(String path, String docPath) {
		super(path);
		this.docPath = docPath;
		this.beginIndex = this.docPath.length()+1;
	}

	/**
	 * 过滤文件
	 * @param file 待考察的文件
	 * @return 文件符合条件，返回true，否则返回false
	 */
	private boolean filter(File file) {
		boolean result = false;
		String name = file.getName();// 文件名,例如"overview-tree.html"
		String ext = Util.getFileExt(name);// 后缀
		if (ext.equals(".htm") || ext.equals(".html")) {// html文件
			// 过滤掉allclasses-frame.html(因为与allclasses-noframe.html内容重复)和临时文件(以".chm.writer.tmp.html"结尾)
			if (!name.equals("allclasses-frame.html")
					&& !name.endsWith(".chm.writer.tmp.html")) {
				result = true;
			}
		}
		return result;
	}

	/**
	 * @param file 当前考察的文件或目录
	 * @param isRoot 是否是JavaDoc的根目录
	 * @param session Hibernate会话对象
	 * @throws IOException
	 */
	private void parse(File file, boolean isRoot,Session session) throws IOException {
		if (file.isDirectory()) {// 目录
			if (isRoot) {// 根目录
				this.writeLn("<!DOCTYPE HTML PUBLIC \"-//IETF//DTD HTML//EN\">");
				this.writeLn("<HTML><HEAD></HEAD><BODY>");
				this.writeLn("<OBJECT type=\"text/site properties\"><param name=\"Window Styles\" value=\"0x800025\"></OBJECT>");
			} else {// 非根目录
				String name = file.getName();// 文件名,例如"org"
				if (!name.startsWith("chm_writer_tmp")) {
					this.writeLn(String
							.format("<LI><OBJECT type=\"text/sitemap\"><param name=\"Name\" value=\"%s\"></OBJECT>",
									name));
				}
			}
			this.writeLn("<UL>");
			for (File subFile : file.listFiles()) {// 遍历目录下所有"文件/目录"
				this.parse(subFile, false, session);// 递归
			}
			this.writeLn("</UL>");
			if (isRoot) {
				this.writeLn("</BODY></HTML>");
			}
		} else {// 文件
			String absolutePath=file.getAbsolutePath();//文件绝对路径
			String fileName=file.getName();//文件名
			//判断是否是索引HTML文件
			if(fileName.startsWith("index-")){//文件名以"index-"打头的文件
				//将索引HTML文件路径保存到表index_html_file中,用于hhk文件的生成
				IndexHtmlFile ihf=new IndexHtmlFile();
				ihf.setPath(absolutePath);
				session.save(ihf);
			}
			String relativePath = file.getAbsolutePath().substring(this.beginIndex);// 文件相对于JavaDoc目录的路径
			String fileExt = Util.getFileExt(fileName);//文件后缀,例如".html"
			if (!relativePath.isEmpty() && !fileExt.equals(".hhc")
					&& !fileExt.equals(".hhk") && !fileExt.equals(".hhp")) {
				// 将文件路径保存到表file中，用于HHP的生成
				FilePath fp = new FilePath();
				fp.setPath(relativePath);
				session.save(fp);
			}
			if (this.filter(file)) {// 文件满足过滤条件
				String title = Util.getTitle(file, "utf-8");// 页面标题
				if (!title.isEmpty()) {// 标题非空
					this.writeLn(String
							.format("<LI><OBJECT type=\"text/sitemap\"><param name=\"Name\" value=\"%s\"><param name=\"Local\" value=\"%s\"></OBJECT>",
									title, relativePath));
				}
			}
		}
	}

	@Override
	public boolean generate() {
		boolean result = false;
		if (open()) {
			Session session = HibernateHelper.getSessionFactory().openSession();
			Transaction tx=session.beginTransaction();
			try {
				parse(new File(docPath), true, session);// 有可能抛出IOException
				result = true;
			} catch (Exception e) {
				e.printStackTrace();
			}
			tx.commit();
			session.close();
			close();
		}
		return result;
	}
}
