package chm.writer.hh;

import java.util.List;
import org.hibernate.Session;
import chm.writer.hibernate.HibernateHelper;
import chm.writer.hibernate.Entity.FilePath;

/**
 * 项目Project文件
 * @author smilethat@qq.com
 */
public class HHP extends HH {
	private String chmPath;
	private String title;
	/**
	 * @param path hhp文件路径
	 * @param chmPath 待生成的chm文件的路径
	 * @param title 待生成的chm文件的标题
	 */
	public HHP(String path,String chmPath,String title) {
		super(path);
		this.chmPath=chmPath;
		this.title=title;
	}
	@Override
	public boolean generate() {
		boolean result = false;
		//打开文件
		if (this.open()) {
			// 写[OPTIONS]
			this.writeLn("[OPTIONS]");
			this.writeLn("Compatibility=1.1 or later");// 兼容性：1.1及后继版本
			this.writeLn("Language=0x804 中文(中国)");// 语言:简体中文
			this.writeLn(String.format("Compiled file=%s", chmPath));// 待生成的chm文件的路径
			this.writeLn("Default topic=index.html");// 首页
			this.writeLn(String.format("Title=%s", title));// 标题
			this.writeLn("Contents file=tmp.hhc");// 目录文件
			this.writeLn("Index file=tmp.hhk");// 索引文件
			// 写[FILES]
			this.writeLn("[FILES]");
			//从数据库的表file中去取
			Session session=HibernateHelper.getSessionFactory().openSession();
			@SuppressWarnings("unchecked")
			List<chm.writer.hibernate.Entity.FilePath>files=session.createQuery("from FilePath").list();
			for(FilePath file:files){
				this.writeLn(file.getPath());
			}
			session.close();
			//关闭文件
			this.close();
			result = true;
		}
		return result;
	}
	
	public void clean(){
		super.clean();
		Session session=HibernateHelper.getSessionFactory().openSession();
		session.createSQLQuery("truncate table file_path").executeUpdate();
		session.close();
	}
}
