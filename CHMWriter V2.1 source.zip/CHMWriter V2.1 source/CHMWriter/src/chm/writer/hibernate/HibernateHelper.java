package chm.writer.hibernate;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

/**
 * Hibernate帮助类,用于获取会化工厂,打开会话
 * @author smilethat@qq.com
 */
public class HibernateHelper {
	private static final SessionFactory SESSION_FACTORY = new Configuration()
			.configure().buildSessionFactory();//常量
	/**
	 * @return 会话工厂
	 */
	public static SessionFactory getSessionFactory() {
		return SESSION_FACTORY;
	}
}
