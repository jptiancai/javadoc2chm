package chm.writer;

import java.io.File;
import java.io.InputStream;
import java.util.Scanner;
import chm.writer.hh.HHC;
import chm.writer.hh.HHK;
import chm.writer.hh.HHP;

/**
 * 
 * 主类 2012-3-14
 * 
 * @author smilethat@qq.com
 * 
 */
public class CHM {
	/**
	 * 生成chm
	 * 
	 * @param docPath
	 *            JAVA doc文档路径,例如"c:\docs\javadoc"
	 * @param compiledFile
	 *            待生成的chm文件名,例如"api.chm"
	 */
	public boolean generate(String docPath, String compiledFile) {
		boolean result = false;
		if (docPath.charAt(docPath.length() - 1) != '\\') {
			docPath += "\\";
		}
		// hhp,hhc,hhk文件路径
		String hhpPath = docPath + "tmp.hhp";
		String hhcPath = docPath + "tmp.hhc";
		String hhkPath = docPath + "tmp.hhk";
		//
		String pairPath = "tmp.pair";
		//
		HHC hhc = new HHC(hhcPath, pairPath, docPath);
		HHK hhk = new HHK(hhkPath, pairPath);
		HHP hhp = new HHP(hhpPath, pairPath, compiledFile, hhcPath, hhkPath);
		try {
			if (hhc.generate() && hhk.generate() && hhp.generate()) {//hhc必须先生成
				InputStream in = null;
				try {
					// 调用hhc.exe
					Process process = Runtime.getRuntime().exec(
							String.format("hhc\\hhc.exe %s", hhpPath));
					in = process.getInputStream();
					while (true) {// 等待hhc.exe进程的结束
						if (in.read() == -1) {
							result = true;
							break;
						}
					}
				} catch (Exception e) {
					e.printStackTrace();
				} finally {
					try {
						if (in != null) {
							in.close();
						}
					} catch (Exception e) {
					}
				}
			}
		} finally {
			Util.deleteFile(hhkPath);
			Util.deleteFile(hhcPath);
			Util.deleteFile(hhpPath);
			Util.deleteFile(pairPath);
		}
		return result;
	}

	/**
	 * 主函数
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in, "GBK");// 用于控制台输入
		scanner.useDelimiter("\r\n");// 设置分隔符
		System.out.println("欢迎使用JAVA doc文档转CHM工具V1.3\n"
				+ "程序只能运行在Windows平台上,作者:smilethat@qq.com");
		while (true) {
			System.out.println("请输入JAVA doc文档目录,例如:c:\\docs\\javadoc");
			String path = scanner.next();
			// 判断path有效性
			File tmp = new File(path);
			if (!tmp.exists() || !tmp.isDirectory()) {
				System.out.println("指定路径不是一个有效的目录");
				continue;
			}
			System.out.println("请输入待生成的chm文件名,例如:api.chm");
			String chmName = scanner.next();
			System.out.println(String.format(
					"您的JAVA doc文档目录是%s,\n待生成的chm文件名是%s\n确定输入y;\n否则输入n,重新进行输入",
					path, chmName));
			String key = scanner.next();
			if (key.toLowerCase().equals("y")) {
				System.out.println("正在生成(如果doc文档较大,将耗费较长时间)...");
				if (new CHM().generate(path,
						new File(chmName).getAbsolutePath())) {// 新建CHM对象,生成chm文件)
					System.out.println("chm文档生成完毕!");
				} else {
					System.out.println("出错,无法生成chm文档!");
				}
				break;
			} else {
				continue;
			}
		}
		scanner.close();
	}
}
