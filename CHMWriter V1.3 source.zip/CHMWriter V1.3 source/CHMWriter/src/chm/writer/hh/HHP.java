package chm.writer.hh;

import java.io.File;
import chm.writer.pair.Pair;
import chm.writer.pair.PairIterator;
import chm.writer.pair.PairReader;

/**
 * 
 * 项目
 * @author smilethat@qq.com
 *
 */
public class HHP extends HH {
	private String compiledFile;
	private String hhcPath;
	private String hhkPath;
	public HHP(String path, String pairPath,String compiledFile,String hhcPath,String hhkPath) {
		super(path, pairPath);
		this.compiledFile=compiledFile;
		this.hhcPath=hhcPath;
		this.hhkPath=hhkPath;
	}
	@Override
	public boolean generate() {
		boolean result = false;
		if(this.open()){
			// 写入[OPTIONS]
			this.writeLn("[OPTIONS]");
			this.writeLn("Compatibility=1.1 or later");//兼容
			this.writeLn(String.format("Compiled file=%s", compiledFile));//编译后的文件路径
			this.writeLn("Default topic=index.html");//默认主题
			this.writeLn(String.format("Title=%s", new File(compiledFile).getName()));// chm标题同文件名相同
			this.writeLn(String.format("Contents file=%s", this.hhcPath));// 目录
			this.writeLn(String.format("Index file=%s", this.hhkPath));// 索引
			this.writeLn("Language=0x804 中文(中国)");// 语言:简体中文
			// 写入[FILES]
			this.writeLn("[FILES]\n");
			PairReader reader=new PairReader(pairPath);
			PairIterator iterator=reader.iterator();
			if(iterator!=null){
				while(iterator.hasNext()){
					Pair pair=iterator.next();
					this.writeLn(pair.getValue());
				}
				iterator.close();
				result=true;
			}
		}
		this.close();
		return result;
	}

}
