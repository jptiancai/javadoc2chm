package chm.writer.hh;

import chm.writer.pair.Pair;
import chm.writer.pair.PairIterator;
import chm.writer.pair.PairReader;

/**
 * 
 * 索引
 * @author smilethat@qq.com
 *
 */
public class HHK extends HH {
	public HHK(String path,String pairPath){
		super(path, pairPath);
	}
	@Override
	public boolean generate() {
		boolean result=false;
		if(this.open()){
			this.writeLn("<!DOCTYPE HTML PUBLIC \"-//IETF//DTD HTML//EN\">");
			this.writeLn("<HTML><HEAD></HEAD><BODY><UL>");
			PairReader reader=new PairReader(pairPath);
			PairIterator iterator=reader.iterator();
			if(iterator!=null){
				while(iterator.hasNext()){
					Pair pair=iterator.next();
					this.writeLn("<LI><OBJECT type=\"text/sitemap\">");
					this.writeLn(String.format("<param name=\"Name\" value=\"%s\">",
							pair.getKey()));// 键
					this.writeLn(String.format("<param name=\"Local\" value=\"%s\">",
							pair.getValue()));// 值
					this.writeLn("</OBJECT>");
				}
				iterator.close();
				result=true;
			}
			this.writeLn("</UL></BODY></HTML>");
		}
		this.close();
		return result;
	}

}
