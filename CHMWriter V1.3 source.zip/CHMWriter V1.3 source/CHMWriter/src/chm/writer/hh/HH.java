package chm.writer.hh;
import java.io.*;
public abstract class HH {
	protected String path;
	protected String pairPath;
	protected PrintWriter writer;
	public HH(String path,String pairPath){
		this.path=path;
		this.pairPath=pairPath;
		
	}
	public abstract boolean generate();
	protected void writeLn(String txt){
		this.writer.println(txt);
	}
	protected boolean open(){
		boolean result=false;
		try {
			this.writer=new PrintWriter(new BufferedWriter(new FileWriter(this.path)));
			result=true;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return result;
	}
	protected boolean close(){
		boolean result=false;
		try {
			if(this.writer!=null){
				this.writer.close();
				result=true;
			}
		} catch (Exception e) {
		}
		return result;
	}
}
