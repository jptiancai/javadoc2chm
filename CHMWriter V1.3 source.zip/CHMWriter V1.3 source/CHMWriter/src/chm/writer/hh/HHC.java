package chm.writer.hh;

import java.io.File;
import java.io.IOException;

import chm.writer.Util;
import chm.writer.pair.Pair;
import chm.writer.pair.PairWriter;

/**
 * 
 * 目录
 * @author smilethat@qq.com
 *
 */
public class HHC extends HH {
	private String docPath;
	private PairWriter writer;
	private int beginIndex;
	public HHC(String path,String pairPath,String docPath){
		super(path, pairPath);
		this.docPath=docPath;
		this.beginIndex=this.docPath.length();
	}
	private void parse(File file, boolean root) throws IOException {
		if (file.isDirectory()) {// 文件夹
			if (root) {// 根目录
				this.writeLn("<!DOCTYPE HTML PUBLIC \"-//IETF//DTD HTML//EN\">");
				this.writeLn("<HTML><HEAD></HEAD><BODY>");
				this.writeLn("<OBJECT type=\"text/site properties\"><param name=\"Window Styles\" value=\"0x800025\"></OBJECT>");
			} else {// 非根目录
				String name = file.getName();// 文件名
				this.writeLn(String
						.format("<LI><OBJECT type=\"text/sitemap\"><param name=\"Name\" value=\"%s\"></OBJECT>",
								name));
			}
			this.writeLn("<UL>");
			for (File subFile : file.listFiles()) {// 遍历文件夹下所有"文件/文件夹"
				parse(subFile, false);
			}
			this.writeLn("</UL>");
			if (root) {
				this.writeLn("</BODY></HTML>");
			}
		} else {// 文件
			String path = file.getAbsolutePath();// 文件绝对路径
			String ext = Util.getFileExt(path);//后缀
			if (ext.equals(".htm") || ext.equals(".html")) {// html文件
				if (!file.getName().equals("allclasses-frame.html")) {// 过滤掉allclasses-frame.html,因为与allclasses-noframe.html内容重复
					String name = Util.getTitle(path);// 页面标题
					if (!name.isEmpty()) {// 标题非空
						path=path.substring(this.beginIndex);//转为相对路径
						this.writer.write(new Pair(name, path));
						this.writeLn(String
								.format("<LI><OBJECT type=\"text/sitemap\"><param name=\"Name\" value=\"%s\"><param name=\"Local\" value=\"%s\"></OBJECT>",
										name, path));
					}
				}
			}
		}
	}
	@Override
	public boolean generate() {
		boolean result=false;
		this.writer=null;
		try {
			this.writer=new PairWriter(this.pairPath);
			if(this.open()){
				this.parse(new File(this.docPath), true);
				result=true;
			}
			this.close();
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				if(this.writer!=null){
					this.writer.close();
				}
			} catch (Exception e) {
			}
		}
		return result;
	}

}
