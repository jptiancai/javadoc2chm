package chm.writer.pair;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.BufferedOutputStream;

/**
 * 
 * 用于将键值对写入到文件
 * @author smilethat@qq.com
 * 调用示例:
 * PairWriter writer=null;
 * try{
 * 	  writer=new PairWriter("data.tmp");
 * 	  writer.write(new Pair("key1","value1"));
 * 	  writer.write(new Pair("key2","value2"));
 * }catch(Exception e){
 * 	 e.printStackTrace();
 * }finally{
 *   try{
 *   	if(writer!=null){
 *   		writer.close();
 *   	}
 *   }catch(Exception e){
 *   }
 * }
 *
 */
public class PairWriter extends ObjectOutputStream {
	/**
	 * 构造函数
	 * @param path 存放键值对数据的文件路径
	 * @throws IOException
	 */
	public PairWriter(String path)throws IOException{
		super(new BufferedOutputStream(new FileOutputStream(path)));
	}
	/**
	 * 将指定键值对写入到文件中
	 * @param pair
	 * @throws IOException
	 */
	public void write(Pair pair)throws IOException{
		super.writeObject(pair);
		super.reset();
	}
}
