package chm.writer.pair;

import java.io.File;
import java.io.IOException;

public class Test {
	public static void main(String[] args) {
		String path="d:/tmp.data";
		//写
		PairWriter writer=null;
		try {
			writer=new PairWriter(path);
			writer.write(new Pair("key1","value1"));
			writer.write(new Pair("key2","value2"));
			writer.write(new Pair("key3","value3"));
		}catch (IOException e) {
			e.printStackTrace();
		}finally{
			if(writer!=null){
				try {
					writer.close();
				} catch (IOException e) {
				}
			}
		}
		//读
		PairReader reader=new PairReader(path);
		PairIterator iterator=reader.iterator();
		if(iterator!=null){
			while(iterator.hasNext()){
				System.out.println(iterator.next());
			}
			iterator.close();
		}
		//
		new File(path).delete();
	}

}
