package chm.writer.pair;

import java.io.IOException;

/**
 * 用于从文件中读取键值对
 * @author smilethat@qq.com
 * 调用示例:
 * PairReader reader=new PairReader("data.tmp");
 * PairIterator iterator=reader.iterator();
 * if(iterator!=null){
 * 		while(iterator.hasNext()){
 * 			Pair pair=iterator.next();
 * 			...
 * 		}
 * 		iterator.close();
 * }
 */
public class PairReader implements Iterable<Pair> {
	/**
	 * 存放键值对数据的文件路径
	 */
	private String path;
	/**
	 * 构造函数
	 * @param path 存放键值对数据的文件路径
	 */
	public PairReader(String path) {
		this.path=path;
	}
	@Override
	public PairIterator iterator(){
		PairIterator pairIterator=null;
		try {
			pairIterator=new PairIterator(this.path);
		} catch (IOException e) {
			e.printStackTrace();
			pairIterator=null;
		}
		return pairIterator;
	}
}
