package chm.writer.pair;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.Iterator;
import java.io.BufferedInputStream;

/**
 * 
 * 键值对迭代器
 * @author smilethat
 *
 */
public class PairIterator implements Iterator<Pair> {
	private ObjectInputStream in;
	private Pair pair;
	public PairIterator(String path)throws IOException{
		this.in=new ObjectInputStream(new BufferedInputStream(new FileInputStream(path)));
	}
	@Override
	public boolean hasNext() {
		try {
			this.pair=(Pair)in.readObject();
		} catch (Exception e) {//EOFException
			this.pair=null;
		}
		return this.pair!=null;
	}

	@Override
	public Pair next() {
		return this.pair;
	}

	@Override
	public void remove() {
		;
	}
	
	public void close(){
		if(this.in!=null){
			try {
				this.in.close();
			} catch (IOException e) {
			}
		}
	}
}
