package chm.writer;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Util {
	/**
	 * 获取指定文本文件的字符编码
	 * @param path 文本文件路径
	 * @return "gb2312"或"utf-8"
	 */
	public static String getCharsetName(String path){
		String charsetName="gb2312";//ANSI 
		byte[]bytes=new byte[3];
		FileInputStream in=null;
		try {
			in=new FileInputStream(path);
			if(in.read(bytes)==3){
				if(bytes[0]==(byte)0xEF && bytes[1]==(byte)0xBB && bytes[2]==(byte)0xBF){
					charsetName="utf-8";
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				if(in!=null){
					in.close();
				}
			} catch (Exception e) {
			}
		}
		return charsetName;
	}
	/**
	 * 获取html文件的页面标题
	 * 
	 * @param path
	 *            html文件路径,例如"c:\test.html"
	 * @return 页面标题
	 */
	public static String getTitle(String path) {
		String title = "";
		BufferedInputStream in = null;// 文件输入流
		try {
			in = new BufferedInputStream(new FileInputStream(path));//文件->流
			byte[] bytes = new byte[1024];
			in.read(bytes);// 流->byte[]
			String txt = new String(bytes,getCharsetName(path));// byte[]->String
			// 利用正则表达式查找页面标题(位于<title>标签内)
			Pattern pattern = Pattern.compile("(<title>)([^<(]*)",
					Pattern.CASE_INSENSITIVE);// 不区分大小写
			Matcher matcher = pattern.matcher(txt);// 进行匹配
			if (matcher.find()) {// 找到
				title = matcher.group(2).trim();// group(1)的值为"<title>",group(2)的值为标题,标题要去掉左右空白字符(包括回车换行符)
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (in != null) {
					in.close();
				}
			} catch (Exception e) {
			}
		}
		return title;
	}

	/**
	 * 获取文件后缀名
	 * 
	 * @param path
	 *            文件路径,例如"c:\test.html"
	 * @return 文件后缀(小写),例如".html"
	 */
	public static String getFileExt(String path) {
		int beginIndex = path.lastIndexOf(".");
		if (beginIndex == -1) {//找不到"."
			return "";
		} else {
			return path.substring(beginIndex).toLowerCase();
		}
	}
	
	/**
	 * 删除文件
	 * 
	 * @param path
	 *            待删除的文件路径,例如"tmp.hhp"
	 */
	public static void deleteFile(String path) {
		new File(path).delete();
	}
}
