package chm.writer.hh;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import chm.writer.Util;

/**
 * 目录Contents
 * @author smilethat@qq.com
 */
public class HHC extends HH {
	private String docPath;
	private int beginIndex;
	private Collection<String> files;

	/**
	 * @param path hhc文件路径
	 * @param docPath Java Doc目录
	 */
	public HHC(String path, String docPath) {
		super(path);
		this.docPath = docPath;
		//
		this.beginIndex = this.docPath.length()+1;
		this.files = new ArrayList<String>();
	}

	/**
	 * @return 生成chm所涉及到的所有文件
	 */
	public Collection<String> getFiles() {
		return files;
	}

	/**
	 * 过滤文件
	 * @param file
	 * @return
	 */
	private boolean filter(File file) {
		boolean result = false;
		String name = file.getName();// 文件名,例如"overview-tree.html"
		String ext = Util.getFileExt(name);// 后缀
		if (ext.equals(".htm") || ext.equals(".html")) {// html文件
			// 过滤掉allclasses-frame.html(因为与allclasses-noframe.html内容重复)和临时文件(以".chm.writer.tmp.html"结尾)
			if (!name.equals("allclasses-frame.html")
					&& !name.endsWith(".chm.writer.tmp.html")) {
				result = true;
			}
		}
		return result;
	}

	/**
	 * @param file
	 *            当前考察的文件或目录
	 * @param isRoot
	 *            是否是根目录
	 * @throws IOException
	 */
	private void parse(File file, boolean isRoot) throws IOException {
		if (file.isDirectory()) {// 目录
			if (isRoot) {// 根目录
				this.writeLn("<!DOCTYPE HTML PUBLIC \"-//IETF//DTD HTML//EN\">");
				this.writeLn("<HTML><HEAD></HEAD><BODY>");
				this.writeLn("<OBJECT type=\"text/site properties\"><param name=\"Window Styles\" value=\"0x800025\"></OBJECT>");
			} else {// 非根目录
				String name = file.getName();// 文件名,例如"org"
				this.writeLn(String
						.format("<LI><OBJECT type=\"text/sitemap\"><param name=\"Name\" value=\"%s\"></OBJECT>",
								name));
			}
			this.writeLn("<UL>");
			for (File subFile : file.listFiles()) {// 遍历目录下所有"文件/目录"
				this.parse(subFile, false);// 递归
			}
			this.writeLn("</UL>");
			if (isRoot) {
				this.writeLn("</BODY></HTML>");
			}
		} else {// 文件
			String path = file.getAbsolutePath().substring(this.beginIndex);// 页面相对路径
			if(!path.isEmpty()){
				this.files.add(path);
			}
			if (this.filter(file)) {
				String name = Util.getTitle(file);// 页面标题
				if (!name.isEmpty()) {// 标题非空
					this.writeLn(String
							.format("<LI><OBJECT type=\"text/sitemap\"><param name=\"Name\" value=\"%s\"><param name=\"Local\" value=\"%s\"></OBJECT>",
									name, path));
				}
			}
		}
	}

	@Override
	public boolean generate() {
		boolean result = false;
		this.files.clear();
		if (this.open()) {
			try {
				this.parse(new File(this.docPath), true);
				result = true;
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		this.close();
		return result;
	}
}
