package chm.writer.hh;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import org.htmlparser.Parser;
import org.htmlparser.filters.TagNameFilter;
import org.htmlparser.util.NodeList;
import org.htmlparser.util.ParserException;
import chm.writer.Entry;
import chm.writer.Pair;
import chm.writer.Util;

/**
 * 索引,Keys
 * @author smilethat@qq.com
 */
public class HHK extends HH {
	private String docPath;
	/**
	 * Entry映射
	 */
	private Map<String, List<Entry>> entryMap;
	/**
	 * 临时文件集
	 */
	private Collection<String> tmpFiles;
	/**
	 * 键值对集
	 */
	private Collection<Pair> pairs;

	/**
	 * 构造函数
	 * @param path hhk文件路径
	 * @param docPath Java Doc目录路径
	 */
	public HHK(String path,String docPath) {
		super(path);
		this.docPath=docPath;
		//
		this.entryMap = new HashMap<String, List<Entry>>();
		this.tmpFiles = new ArrayList<String>();
		this.pairs = new ArrayList<Pair>();
	}

	private boolean generateEntryMap() {
		boolean result=false;
		this.entryMap.clear();
		try {
			//解析index-all.html文件
			Parser parser = new Parser(String.format("%s/index-all.html",
					this.docPath));
			NodeList dt = parser.parse(new TagNameFilter("dt"));//找到所有的<dt>标签
			for (int i = 0; i < dt.size(); i++) {
				Entry entry = Entry.parse(dt.elementAt(i));//<dt>标签->Entry对象
				if (entry != null) {
					String name = entry.getName();
					if (this.entryMap.containsKey(name)) {
						this.entryMap.get(name).add(entry);
					} else {
						List<Entry> list = new ArrayList<Entry>();
						list.add(entry);
						this.entryMap.put(name, list);
					}
				}
			}
			result=true;
		} catch (ParserException e) {
			e.printStackTrace();
		}
		return result;
	}

	private void generatePairsAndTmpFiles() {
		this.pairs.clear();
		this.tmpFiles.clear();
		for (String name : this.entryMap.keySet()) {
			List<Entry> list = this.entryMap.get(name);
			if (list.size() > 1) {
				//同一个name,对应多个Entry,要生成一个临时html文件
				StringBuilder content = new StringBuilder();
				content.append(String.format(
						"<html><head><meta http-equiv='Content-Type' content='text/html; charset=utf-8'/><title>Occurences of %s</title></head>",
						name));
				content.append("<body style='{font-family:Verdana,Arial; font-size:10pt; }'>");
				content.append(String
						.format("<dl><dt><b>%s</b>:", name));
				for (Entry entry : list) {
					content.append(String.format(
							"<dd><a href='%s'>%s</a></dd>", entry.getPath(),
							entry.getCompleteName()));
				}
				content.append("</dl></body></html>");
				Random random=new Random();
				String randomName = String.format("%s_%d_%d.chm.writer.tmp.html",
						name, random.nextInt(),random.nextInt());// 临时文件名
				String path=String.format("%s/%s", this.docPath, randomName);//绝对路径
				Util.save(content.toString(),path);
				this.pairs.add(new Pair(name, randomName));
				this.tmpFiles.add(path);
			} else {
				this.pairs.add(new Pair(name, list.get(0).getPath()));
			}
		}
	}

	@Override
	public boolean generate() {
		boolean result = false;
		//必须先调用generateEntryMap,再调用generatePairsAndTmpFiles
		if(this.generateEntryMap()){
			this.generatePairsAndTmpFiles();
			if (this.open()) {
				this.writeLn("<!DOCTYPE HTML PUBLIC \"-//IETF//DTD HTML//EN\">");
				this.writeLn("<HTML><HEAD></HEAD><BODY><UL>");
				for (Pair pair : pairs) {
					this.writeLn("<LI><OBJECT type=\"text/sitemap\">");
					this.writeLn(String.format(
							"<param name=\"Name\" value=\"%s\">", pair.getKey()));// 键
					this.writeLn(String.format(
							"<param name=\"Local\" value=\"%s\">", pair.getValue()));// 值
					this.writeLn("</OBJECT>");
				}
				this.writeLn("</UL></BODY></HTML>");
				result = true;
			}
			this.close();
		}
		return result;
	}
	
	public void clean(){
		super.clean();
		for(String path:this.tmpFiles){//删除临时文件
			Util.deleteFile(path);
		}
	}
}
