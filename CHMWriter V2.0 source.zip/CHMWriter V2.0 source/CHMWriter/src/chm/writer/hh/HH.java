package chm.writer.hh;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import chm.writer.Util;

/**
 * HHC,HHK以及HHP的抽象父类
 * @author smilethat@qq.com
 */
public abstract class HH {
	private String path;
	private PrintWriter writer;
	/**
	 * @param path 文件路径
	 */
	public HH(String path){
		this.path=path;
	}
	/**
	 * 生成文件
	 * @return 生成是否成功
	 */
	public abstract boolean generate();
	/**
	 * 往文件中写入一字符串,并换行
	 * @param txt 待写入的字符串
	 */
	protected void writeLn(String txt){
		if(this.writer!=null){
			this.writer.println(txt);
		}
	}
	/**
	 * 打开文件
	 * @return 打开是否成功
	 */
	protected boolean open(){
		boolean result=false;
		try {
			//FileWriter->BufferedWriter->PrintWriter
			this.writer=new PrintWriter(new BufferedWriter(new FileWriter(this.path)));
			result=true;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return result;
	}
	/**
	 * 关闭文件
	 */
	protected void close(){
		if(this.writer!=null){
			this.writer.close();
		}
	}
	/**
	 * 清理,删掉所对应的文件
	 */
	public void clean(){
		Util.deleteFile(this.path);
	}
}
