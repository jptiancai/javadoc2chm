package chm.writer.hh;

import java.util.Collection;

/**
 * 项目Project
 * @author smilethat@qq.com
 */
public class HHP extends HH {
	private String compiledFile;
	private String title;
	private Collection<String> files;
	/**
	 * @param path hhp文件路径
	 * @param compiledFile 待生成的chm文件的路径
	 * @param title 待生成的chm文件的标题
	 * @param files 所涉及到的文件的集合
	 */
	public HHP(String path,String compiledFile,String title,Collection<String> files) {
		super(path);
		this.compiledFile=compiledFile;
		this.title=title;
		this.files=files;
	}
	@Override
	public boolean generate() {
		boolean result = false;
		if (this.open()) {
			// 写[OPTIONS]
			this.writeLn("[OPTIONS]");
			this.writeLn("Compatibility=1.1 or later");// 兼容1.1及后继版本
			this.writeLn("Language=0x804 中文(中国)");// 语言:简体中文
			this.writeLn(String.format("Compiled file=%s", this.compiledFile));// 待生成的chm文件的路径
			this.writeLn("Default topic=index.html");// 默认主题
			this.writeLn(String.format("Title=%s", this.title));// 标题
			this.writeLn("Contents file=tmp.hhc");// 目录文件
			this.writeLn("Index file=tmp.hhk");// 索引文件
			// 写[FILES]
			this.writeLn("[FILES]");
			for (String file : files) {
				this.writeLn(file);
			}
			result = true;
		}
		this.close();
		return result;
	}
}
