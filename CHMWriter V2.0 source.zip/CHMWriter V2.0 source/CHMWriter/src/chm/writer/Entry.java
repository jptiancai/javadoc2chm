package chm.writer;

import org.htmlparser.Node;
import org.htmlparser.tags.LinkTag;
import org.htmlparser.util.NodeList;

/**
 * 用于构建HHK文件
 * @author smilethat@qq.com
 */
public class Entry {
	private String name;
	private String path;
	private String completeName;

	/**
	 * @return 名称,类名或方法名,例如"accumulate"
	 */
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return 路径,例如"net\sf\json\JSONObject.html#accumulate(java.lang.String, boolean)"
	 */
	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	/**
	 * @return 全名,例如"net.sf.json.JSONObject.accumulate(java.lang.String, boolean)"
	 */
	public String getCompleteName() {
		return completeName;
	}

	public void setCompleteName(String completeName) {
		this.completeName = completeName;
	}

	/**
	 * 由超链接生成全名
	 * @param href
	 *            例如
	 *            "./net/sf/json/JSONObject.html#accumulate(java.lang.String, double)"
	 * @return 
	 *         例如"net.sf.json.JSONObject.accumulate(java.lang.String, double)"
	 */
	private static String toCompleteName(String href) {
		// 去掉首尾空白
		String result = href.trim();
		// 去掉打头的"./"
		if(result.startsWith("./")){
			result = result.substring(2);
		}
		// "/"->"."
		result = result.replace("/", ".");
		// "#"->"."
		result = result.replace("#", ".");
		// 去掉".html"或".htm"
		result=result.replace(".html", "");
		result=result.replace(".htm", "");
		return result;
	}

	/**
	 * 由超链接生成路径
	 * @param href
	 *            例如
	 *            "./net/sf/json/JSONObject.html#accumulate(java.lang.String, double)"
	 * @return 例如"net\sf\json\JSONObject.html#accumulate(java.lang.String,double)"
	 */
	private static String toPath(String href) {
		// 去掉首尾空白
		String result = href.trim();
		// 去掉打头的"./"
		if(result.startsWith("./")){
			result = result.substring(2);
		}
		// "/"->"\"
		result = result.replace("/", "\\");
		return result;
	}

	/**
	 * @param name
	 *            例如"accumulate(String, double)"
	 * @return 例如"accumulate"
	 */
	private static String toName(String name) {
		// 去掉首尾空白
		String result = name.trim();
		// 截取"("前的子字符串
		int endIndex=result.indexOf("(");
		if(endIndex>-1){
			result = result.substring(0, endIndex);
		}
		return result;
	}

	/**
	 * 解析标签dt,返回Entry对象
	 * @param dt
	 * @return dt对应的Entry对象,解析失败则返回null
	 */
	public static Entry parse(Node dt) {
		Entry result = null;
		/*
		 * <DT> 
		 * 	<A HREF="./net/sf/json/JSONObject.html#accumulate(java.lang.String, double)">
		 * 		<B>accumulate(String, double)</B> 
		 * 	</A> 
		 * 	- Method in classnet.sf.json. 
		 * 	<A HREF="./net/sf/json/JSONObject.html" title="class in net.sf.json">
		 * 		JSONObject 
		 * 	</A> 
		 * </DT>
		 */
		if(dt.toPlainTextString().toLowerCase().indexOf("constructor for class")==-1){//排除掉构造函数
			NodeList list = dt.getChildren();
			for (int i = 0; i < list.size(); i++) {
				Node node = list.elementAt(i);
				if (node instanceof LinkTag) {//找到第一个<A>标签
					LinkTag tag = (LinkTag) node;
					//href="./net/sf/json/JSONObject.html#accumulate(java.lang.String, double)"
					String href = tag.getAttribute("href");
					//tag.toPlainTextString()="accumulate(String, double)"
					String name = toName(tag.toPlainTextString());
					String path = toPath(href);
					String completeName = toCompleteName(href);
					result = new Entry();
					result.setName(name);
					result.setPath(path);
					result.setCompleteName(completeName);
					break;//跳出for循环
				}
			}
		}
		return result;
	}

	public String toString() {
		return String.format("path:%s name:%s completeName:%s", this.path,
				this.name, this.completeName);
	}
}
