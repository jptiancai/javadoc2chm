package chm.writer;

import java.io.File;
import java.io.InputStream;
import chm.writer.hh.HHC;
import chm.writer.hh.HHK;
import chm.writer.hh.HHP;

public class Generator{
	private String docPath;
	private String compiledFile;
	private String title;
 
	/**
	 * @param docPath 例如"D:\JavaLib\json-lib\doc"
	 * @param compiledFile 例如"json-lib.chm"
	 * @param title 例如"JSON-lib的API参考"
	 */
	public Generator(String docPath,String compiledFile,String title){
		this.docPath=Util.cleanDirPath(docPath);
		this.compiledFile=compiledFile;
		this.title=title;
	}
	
	/**
	 * 调用hhc\hhc.exe
	 * @param hhpPath
	 * @return 调用是否成功
	 */
	private boolean callHhcExe(String hhpPath){
		boolean result=false;
		InputStream in = null;
		if(new File("hhc/hhc.exe").exists()){
			try {
				// 调用hhc.exe
				Process process = Runtime.getRuntime().exec(
						String.format("hhc\\hhc.exe %s", hhpPath.replace("/", "\\")));//转Windows路径标识符
				in = process.getInputStream();
				while (true) {// 等待hhc.exe进程的结束
					if (in.read() == -1) {
						break;
					}
				}
				result=true;
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				try {
					if (in != null) {
						in.close();
					}
				} catch (Exception e) {
				}
			}
		}
		return result;
	}
	
	/**
	 * 校验Java Doc目录
	 * @return Java Doc目录是否正确
	 */
	private boolean validateDocPath(){
		boolean result=false;
		File file=new File(this.docPath);
		if(file.exists()&&file.isDirectory()){//路径存在并且是一个目录
			if(new File(String.format("%s/index-all.html",this.docPath)).exists()){//目录下含有文件"index-all.html"
				result=true;
			}
		}
		return result;
	}

	/**
	 * 执行
	 * @return 结果,例如"索引文件创建失败","chm文件生成完毕"等等
	 */
	public String execute() {
		if(!this.validateDocPath()){
			return String.format("%s不是一个有效的Java Doc目录", this.docPath);
		}
		/*
		 * hhk,hhc以及hhp三个文件的生成顺序,必须是:
		 * hhk->hhc->hhp,
		 * 不能颠倒
		 */
		HHK hhk=null;
		HHC hhc=null;
		HHP hhp=null;
		try {
			//三个文件的路径
			String hhcPath = String.format("%s/tmp.hhc", docPath);
			String hhkPath = String.format("%s/tmp.hhk", docPath);
			String hhpPath = String.format("%s/tmp.hhp", docPath);
			//hhk
			hhk = new HHK(hhkPath, docPath);
			if (!hhk.generate()) {
				return "索引文件创建失败";
			}
			//hhc
			hhc = new HHC(hhcPath, docPath);
			if (!hhc.generate()) {
				return "目录文件创建失败";
			}
			//hhp
			hhp = new HHP(hhpPath, compiledFile, title, hhc.getFiles());
			if (!hhp.generate()) {
				return "项目文件创建失败";
			}
			if (!callHhcExe(hhpPath)) {
				return "调用hhc.exe失败";
			}
			return "chm文件生成完毕";
		}finally{
			//清理
			if(hhp!=null){
				hhp.clean();
			}
			if(hhc!=null){
				hhc.clean();
			}
			if(hhk!=null){
				hhk.clean();
			}
		}
	}
}
