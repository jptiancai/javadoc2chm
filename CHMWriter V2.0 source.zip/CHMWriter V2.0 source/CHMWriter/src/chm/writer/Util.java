package chm.writer;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 工具类
 * @author smilethat@qq.com
 */
public class Util {
	/**
	 * 获取指定文本文件的字符编码
	 * 
	 * @param file
	 *            文本文件
	 * @return "gb2312"或"utf-8"
	 */
	public static String getCharsetName(File file) {
		String charsetName = "gb2312";// ANSI
		byte[] bytes = new byte[3];
		FileInputStream in = null;
		try {
			in = new FileInputStream(file);
			if (in.read(bytes) == 3) {//读取前三个字节
				if (bytes[0] == (byte) 0xEF && bytes[1] == (byte) 0xBB
						&& bytes[2] == (byte) 0xBF) {
					charsetName = "utf-8";
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (in != null) {
					in.close();
				}
			} catch (Exception e) {
			}
		}
		return charsetName;
	}

	/**
	 * 获取html文件的页面标题
	 * 
	 * @param file
	 *            html文件
	 * @return 页面标题
	 */
	public static String getTitle(File file) {
		String title = "";
		BufferedInputStream in = null;// 文件输入流
		try {
			in = new BufferedInputStream(new FileInputStream(file));// 文件->流
			byte[] bytes = new byte[1024];
			in.read(bytes);// 流->byte[],只读取前1024个字节
			String txt = new String(bytes, Util.getCharsetName(file));// byte[]->String
			/*
			 * 利用正则表达式查找页面标题(位于<title>标签内)
			 * 例如,对于<TITLE>JSONString (Overview (json-lib jdk 5 API))</TITLE>,
			 * 则title="JSONString"
			 */
			Pattern pattern = Pattern.compile("(<title>)([^<(]*)",
					Pattern.CASE_INSENSITIVE);// 不区分大小写
			Matcher matcher = pattern.matcher(txt);// 进行匹配
			if (matcher.find()) {// 找到
				title = matcher.group(2).trim();// group(1)的值为"<title>",group(2)的值为标题,标题要去掉左右空白字符(包括回车换行符)
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (in != null) {
					in.close();
				}
			} catch (Exception e) {
			}
		}
		return title;
	}

	/**
	 * 获取文件后缀名
	 * 
	 * @param path
	 *            文件路径,例如"c:\test.html"
	 * @return 文件后缀(小写),例如".html"
	 */
	public static String getFileExt(String path) {
		int beginIndex = path.lastIndexOf(".");
		if (beginIndex == -1) {// 找不到"."
			return "";
		} else {
			return path.substring(beginIndex).toLowerCase();
		}
	}

	/**
	 * 获取文件后缀名
	 * @param file
	 * @return
	 */
	public static String getFileExt(File file) {
		return getFileExt(file.getName());
	}

	/**
	 * 删除文件
	 * 
	 * @param path
	 *            待删除的文件路径,例如"tmp.hhp"
	 */
	public static void deleteFile(String path) {
		File file=new File(path);
		if(file.exists()){
			file.delete();
		}
	}

	/**
	 * 将字符串保存为文本文件
	 * 
	 * @param content
	 * @param path
	 * @return 保存是否成功
	 */
	public static boolean save(String content, String path) {
		boolean result = false;
		FileOutputStream out = null;
		try {
			out = new FileOutputStream(path);
			out.write(content.getBytes());
			result = true;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (out != null) {
					out.close();
				}
			} catch (Exception e) {
			}
		}
		return result;
	}

	/**
	 * 清理目录路径,去掉尾部的文件路径分隔符
	 * @param path 例如"d:/javadoc/"
	 * @return 例如"d:/javadoc"
	 */
	public static String cleanDirPath(String path) {
		String result = path.trim();
		while (true) {
			if (result.endsWith("/")) {
				result = result.substring(0, result.length() - 1);
				continue;
			} else if (result.endsWith("\\")) {
				result = result.substring(0, result.length() - 1);
				continue;
			} else {
				break;
			}
		}
		return result;
	}
}
