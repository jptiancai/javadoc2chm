package chm.writer.entity;

/**
 * 索引HTML文件,用于构建HHK文件
 * 
 * @author smilethat@qq.com
 */
public class IndexHtmlFile {
	private String path;

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

}
